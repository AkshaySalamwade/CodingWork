package JAVA_CODES;

public class SwapNumber {


    public static void main(String[] args) {
        

        int a = 16;
        int b = 74;

         a = a+b; // 30
         b = a-b;  //10
         a = a-b; // 10

      
          System.out.println("A :"+a);
          System.out.println("B :"+b);



    }
    
}
